"use strict";
// PREREQUISITES
require("dotenv/config");

const http = require("http");
const express = require("express");
const app = express();
const server = http.createServer(app);
const axios = require("axios");
const mongoose = require("mongoose");

// MONGOOSE CONNECTION
mongoose.connect(process.env.MONGO_URL, {
	useNewUrlParser: true,
	useUnifiedTopology: true,
});

// COLLECTION SCHEMA
const RSSSchema = new mongoose.Schema({
	key: {
		type: String,
	},
	data: {
		type: mongoose.Schema.Types.Mixed,
	},
});
const RSSModel = mongoose.model("cl_rss", RSSSchema);

// API
app.get("/fetch-feeds/:search", async (req, res, next) => {
	const search = req.params.search;

	// Find from collection
	let response = await RSSModel.findOne({ key: search });

	// If response if found from collection then respond the data.
	if (response) {
		return res.status(200).send(response.data);
	}

	// Else ask news api for response.
	const naurl = process.env.NEWSAPI_URL;
	const nakey = process.env.NEWSAPI_KEY;

	const url = `${naurl}?q=${search}&apiKey=${nakey}`;

	const options = {
		method: "GET",
		url,
	};

	response = await axios(options);

    // Insert new api
	const newData = new RSSModel({
		key: search,
		data: response.data,
	});
	await newData.save();

	return res.status(200).send(response.data);
});

// LISTEN
server.listen(process.env.PORT, () => {
	console.log("server is running on port: " + process.env.PORT);
});
